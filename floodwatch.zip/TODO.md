# Frontend prototype outcomes

- [x] A community-tool disclaimer prominently states that Bengaluru FloodWatch is not an official government service and that prototype information is sample-only.
- [x] Simulated Bengaluru map view displays clearly labeled sample flood-report markers without connecting to a live map service. Flood report browsing lets users select sample markers and inspect report details such as location, severity, time, description, and photo evidence.
- [x] Route-check prototype accepts two place names and simulates a route with sample flood warnings or an illustrative clear-route result. No recent reports must not be presented as proof that a route is safe.
- [x] Start-report flow captures a location, severity, description, and locally previewed photo evidence, then ends with a clear simulation notice instead of submitting data.
- [x] Bilingual English and Kannada safety copy presents concise flood precautions and emergency guidance.
- [x] One-tap emergency and helpline actions use visible phone links with confirmation messaging and clear emergency context.
- [x] Responsive, accessible frontend interactions include keyboard-friendly controls, readable status labels, and simulated loading, success, empty, and validation states.
- [x] The delivered application remains frontend-only: no backend, authentication, external API, live map, database, real location capture, remote report submission, or network persistence.
